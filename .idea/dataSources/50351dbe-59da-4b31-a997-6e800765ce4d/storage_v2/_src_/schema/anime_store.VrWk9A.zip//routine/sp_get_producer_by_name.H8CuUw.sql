create
    definer = root@`%` procedure sp_get_producer_by_name(IN search varchar(100))
BEGIN
    SELECT * FROM producer WHERE name LIKE CONCAT('%', search, '%');
END;

